# Proyecto-sena

Proyecto Innube para el SENA. Aquí se hará el proyecto con sus respectivos archivos.

Si tienen dudas, pregunten, especialmente si se trata de cómo usar `git`.